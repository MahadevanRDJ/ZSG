package com.MahadevanRDJ.FlightTicketBooking.DTOs;

public class Passengers {
    private String firstName;
    private String lastName;
    private long contactNumber;
    private String gender;
    private byte age;
    private String city;
    private int passengersId;

    

    public Passengers(String firstName, String lastName, long contactNumber, String gender, byte age, String city,
            int passengersId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNumber = contactNumber;
        this.gender = gender;
        this.age = age;
        this.city = city;
        this.passengersId = passengersId;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public long getContactNumber() {
        return contactNumber;
    }
    public void setContactNumber(long contactNumber) {
        this.contactNumber = contactNumber;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public byte getAge() {
        return age;
    }
    public void setAge(byte age) {
        this.age = age;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public int getPassengersId() {
        return passengersId;
    }
    public void setPassengersId(int passengersId) {
        this.passengersId = passengersId;
    }

    public void display() {
        System.out.println("Passenger ID : " + passengersId);
        System.out.println("First Name : " + firstName);
        System.out.println("Last Name : " + lastName);
        System.out.println("Contact : " + contactNumber);
        System.out.println("Gender : " + gender);
        System.out.println("City : " + city);
        System.out.println("Age : " + age);
    }

    }
