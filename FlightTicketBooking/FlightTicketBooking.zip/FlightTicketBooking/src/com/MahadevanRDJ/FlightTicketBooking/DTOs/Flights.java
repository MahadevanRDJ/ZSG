package com.MahadevanRDJ.FlightTicketBooking.DTOs;

public class Flights {
    private byte flightNumber;
    private String flightName;
    private String departurePlace;
    private String arrivalPlace;
    private int flightFares;

    
    public Flights(byte flightNumber, String flightName, String departurePlace, String arrivalPlace, int flightFares) {
        this.flightNumber = flightNumber;
        this.flightName = flightName;
        this.departurePlace = departurePlace;
        this.arrivalPlace = arrivalPlace;
        this.flightFares = flightFares;
    }

    public byte getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(byte flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public String getDeparturePlace() {
        return departurePlace;
    }

    public void setDeparturePlace(String departurePlace) {
        this.departurePlace = departurePlace;
    }

    public String getArrivalPlace() {
        return arrivalPlace;
    }

    public void setArrivalPlace(String arrivalPlace) {
        this.arrivalPlace = arrivalPlace;
    }

    public int getFlightFares() {
        return flightFares;
    }

    public void setFlightFares(int flightFares) {
        this.flightFares = flightFares;
    }

    public void displays() {
         System.out.println(flightNumber + "    " + flightName + "    " + departurePlace + "    \t" + arrivalPlace + "    \t" + flightFares);
    }
}
