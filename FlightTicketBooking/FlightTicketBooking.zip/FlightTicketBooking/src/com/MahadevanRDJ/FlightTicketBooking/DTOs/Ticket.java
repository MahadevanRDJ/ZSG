package com.MahadevanRDJ.FlightTicketBooking.DTOs;

public class Ticket {
    private byte flightNumber;
    private String flightName;
    private String departurePlace;
    private String arrivalPlace;
    private byte numberOfPassengers;
    private int ticketId;
    private int ticketFare;

    public Ticket(byte flightNumber, String flightName, String departurePlace, String arrivalPlace,
            byte numberOfPassengers, int ticketId, int ticketFare) {
        this.flightNumber = flightNumber;
        this.flightName = flightName;
        this.departurePlace = departurePlace;
        this.arrivalPlace = arrivalPlace;
        this.numberOfPassengers = numberOfPassengers;
        this.ticketId = ticketId;
        this.ticketFare = ticketFare;
    }

    public byte getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(byte flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public String getDeparturePlace() {
        return departurePlace;
    }

    public void setDeparturePlace(String departurePlace) {
        this.departurePlace = departurePlace;
    }

    public String getArrivalPlace() {
        return arrivalPlace;
    }

    public void setArrivalPlace(String arrivalPlace) {
        this.arrivalPlace = arrivalPlace;
    }

    public byte getNumberOfPassengers() {
        return numberOfPassengers;
    }

    public void setNumberOfPassengers(byte numberOfPassengers) {
        this.numberOfPassengers = numberOfPassengers;
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public int getTicketFare() {
        return ticketFare;
    }

    public void setTicketFare(int ticketFare) {
        this.ticketFare = ticketFare;
    }

}
