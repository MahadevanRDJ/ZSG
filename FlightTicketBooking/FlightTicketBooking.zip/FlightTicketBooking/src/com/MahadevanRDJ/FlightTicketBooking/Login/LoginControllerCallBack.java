package com.MahadevanRDJ.FlightTicketBooking.Login;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Admin;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Users;

public interface LoginControllerCallBack {

    void checkCredentials(String username, String password);

    void loginSuccess(Admin admin);

    void loginFailed();


    void loginSuccess(Users user);

    void createUser(String username, String password);

    void checkUserCredentials(String username, String password);
    
}
