package com.MahadevanRDJ.FlightTicketBooking.Login;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Admin;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Users;

public class LoginController implements LoginControllerCallBack, LoginModelControllerCallBack {
    private LoginViewCallBack loginView;
    private LoginModelCallBack loginModel;

    public LoginController(LoginViewCallBack loginView) {
        this.loginView = loginView;
        this.loginModel = new LoginModel(this);
    }

    @Override
    public void checkCredentials(String username, String password) {
        loginModel.checkCredentials(username, password);
    }

    @Override
    public void loginSuccess(Admin admin) {
        loginView.loginSuccess(admin);

    }

    @Override
    public void loginFailed() {
        loginView.loginFailed();

    }

    @Override
    public void loginSuccess(Users user) {
        loginView.loginSuccess(user);
    }

    @Override
    public void createUser(String username, String password) {
        loginModel.addUser(username, password);

    }

    @Override
    public void checkUserCredentials(String username, String password) {
        loginModel.checkUserCredentials(username, password);

    }

}
