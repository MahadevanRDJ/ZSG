package com.MahadevanRDJ.FlightTicketBooking.Login;

import java.util.Scanner;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Admin;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Users;
import com.MahadevanRDJ.FlightTicketBooking.Flights.FlightView;
import com.MahadevanRDJ.FlightTicketBooking.Flights.FlightViewCallBack;

public class LoginView implements LoginViewCallBack {
    LoginControllerCallBack loginController;
    Scanner scanner = new Scanner(System.in);

    public LoginView() {
        this.loginController = new LoginController(this);
    }

    public static void main(String[] args) {
        LoginView loginView = new LoginView();
        loginView.init();
    }

    public void init() {
        int choice;

        do {
            System.out.println("--------------------------------");
            System.out.println("Welcome to Flight Ticket Booking System");
            System.out.println("1. Admin Login");
            System.out.println("2. Add User");
            System.out.println("3. User Login");
            System.out.println("4. Exit");
            System.out.println("Choice : ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    adminLogin();
                    break;
                case 2:
                    addUser();
                    break;
                case 3:
                    userLogin();
                    ;
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        } while (choice != 4);

    }

    private void userLogin() {
        System.out.println("UserName : ");
        String username = scanner.next();
        System.out.println("Password : ");
        String password = scanner.next();
        loginController.checkUserCredentials(username, password);
    }

    private void adminLogin() {
        System.out.println("AdminName: ");
        String username = scanner.next();
        System.out.println("Password : ");
        String password = scanner.next();
        loginController.checkCredentials(username, password);
    }

    private void addUser() {
        System.out.println("UserName : ");
        String username = scanner.next();
        System.out.println("Password : ");
        String password = scanner.next();
        loginController.createUser(username, password);
    }

    @Override
    public void loginSuccess(Admin admin) {
        System.out.println("--------------------------------");
        System.out.println("Login successful, Admin " + admin.getAdminName());
        FlightViewCallBack fBack = new FlightView();
        fBack.init();
    }

    @Override
    public void loginFailed() {
        System.out.println("--------------------------------");
        System.out.println("Login failed");
        System.out.println("Please try again with correct credentials. Thanks!");
        init();
    }

    @Override
    public void loginSuccess(Users user) {
        System.out.println("--------------------------------");
        System.out.println("Login successful, " + user.getUserName());
        System.out.println("Welcome to Flight Reservation System");
        FlightViewCallBack fBack = new FlightView();
        fBack.init();
    }
}
