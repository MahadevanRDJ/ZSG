package com.MahadevanRDJ.FlightTicketBooking.Login;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Admin;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Users;
import com.MahadevanRDJ.FlightTicketBooking.FlightRepository.FlightRepository;

public class LoginModel implements LoginModelCallBack {
    private LoginModelControllerCallBack loginController;

    public LoginModel(LoginModelControllerCallBack loginController) {
        this.loginController = loginController;
    }

    @Override
    public void checkCredentials(String username, String password) {
        Admin admin = FlightRepository.getInstance().getAdmin(username, password);
        if (admin != null) {
            loginController.loginSuccess(admin);
        } else {
            loginController.loginFailed();
        }

    }

    @Override
    public void addUser(String username, String password) {
        FlightRepository.getInstance().addUser(username, password);

    }

    @Override
    public void checkUserCredentials(String username, String password) {
        Users user = FlightRepository.getInstance().getUser(username, password);
        if (user != null) {
            loginController.loginSuccess(user);
        } else {
            loginController.loginFailed();
        }

    }

}
interface LoginModelControllerCallBack{

    void loginSuccess(Users user);

    void loginFailed();

    void loginSuccess(Admin admin);

} 
