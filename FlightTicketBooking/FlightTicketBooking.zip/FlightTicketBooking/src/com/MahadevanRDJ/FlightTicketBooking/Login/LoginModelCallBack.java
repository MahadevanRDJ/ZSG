package com.MahadevanRDJ.FlightTicketBooking.Login;


public interface LoginModelCallBack {

    void checkCredentials(String username, String password);

    void addUser(String username, String password);

    void checkUserCredentials(String username, String password);
    
}
