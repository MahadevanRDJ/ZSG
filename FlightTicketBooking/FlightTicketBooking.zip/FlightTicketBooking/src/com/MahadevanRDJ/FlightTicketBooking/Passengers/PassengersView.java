package com.MahadevanRDJ.FlightTicketBooking.Passengers;

import java.util.List;
import java.util.Scanner;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Passengers;
import com.MahadevanRDJ.FlightTicketBooking.Ticket.TicketView;
import com.MahadevanRDJ.FlightTicketBooking.Ticket.TicketViewCallBack;

public class PassengersView implements PassengersViewCallBack {
    private Scanner scanner = new Scanner(System.in);
    private PassengersControllerCallBack passengersController;
    private byte numberOfPassengers = 0;
    private boolean isPassengerAdded = false;

    public PassengersView() {
        this.passengersController = new PassengersController(this);
    }

    public void init() {
        int choice;
        do {
            System.out.println("--------------------------------");
            System.out.println("1. Add Passengers\n2. Display Passengers\n3. Update passenger \n4. Total Fare\n5. Get Ticket\n5.EXIT");
            System.out.println("Choice : ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    PassengersInformation();
                    break;
                case 2:
                    if (isPassengerAdded)
                        displaysPassengers();
                    break;
                case 3: if(isPassengerAdded) 
                        updatePassenger();
                        break;
                case 4:
                    if(isPassengerAdded)
                        fare();
                    break;
                case 5:
                    if(isPassengerAdded)
                        getTicket();
                    break;
                case 6:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        } while (choice != 4);

    }

    private void PassengersInformation() {
        System.out.println("-------------------------------- Passsengers Information --------------------------------");

        System.out.println("No. of passesengers");
        byte Passengers = scanner.nextByte();
        this.numberOfPassengers += Passengers;
        passengersController.setNumberOfPassengers(numberOfPassengers);
        isPassengerAdded = true;

        for (int i = 0; i < Passengers; i++) {
            System.out.println("\t\t\t\t\tPassenger " + (i + 1) + " Information :");
            System.out.println("First name :");
            String firstName = scanner.next();

            System.out.println("Last name :");
            String lastName = scanner.next();

            System.out.println("Contact number :");
            long contactNumber = scanner.nextLong();

            System.out.println("Gender : ");
            String gender = scanner.next();

            System.out.println("City :");
            String city = scanner.next();

            System.out.println("Age : ");
            byte age = scanner.nextByte();

            passengersController.storePassengers(firstName, lastName, contactNumber, gender, age, city);
        }
    }

    public void updatePassenger() {
        System.out.println("Enter Passengers ID : ");
        int passengersId = scanner.nextInt();
        passengersController.getPassengers(passengersId);
    }

    public void fare() {
        passengersController.storeFare(numberOfPassengers);
    }

    @Override
    public void displaysPassengers() {
        System.out.println("--------------------------------");
        System.out.println("Below displays the passengers information for this journey.");
        passengersController.displayPassengers();
    }

    
    @Override
    public void upadteFields(Passengers passenger) {
        System.out.println("--------------------------------");
        System.out.println("Current Passenger details :");
        passenger.display();

        
        int choice;
        do {
            System.out.println("--------------------------------");
            System.out.println("1. Update First Name ");
            System.out.println("2. Update Last Name");
            System.out.println("3. Update Contact Number");
            System.out.println("4. Update Gender");
            System.out.println("5. Update Age");
            System.out.println("6. Update City");
            System.out.println("7. Go Back to main menu");

            System.out.println("Choice : ");
            choice = scanner.nextInt();
            switch(choice) {
                case 1: {
                    System.out.println("First Name : ");
                    String firstName = scanner.next();
                    passenger.setFirstName(firstName);
                    break;
                }
                case 2: {
                    System.out.println("Last Name : ");
                    String lastName = scanner.next();
                    passenger.setLastName(lastName);
                    break;
                }
                case 3: {
                    System.out.println("Contact : ");
                    long contactNumber = scanner.nextLong();
                    passenger.setContactNumber(contactNumber);
                    break;
                }
                case 4: {
                    System.out.println("Gender : ");
                    String gender = scanner.next();
                    passenger.setGender(gender);
                    break;
                }
                case 5: {
                    System.out.println("Age : ");
                    byte age = scanner.nextByte();
                    passenger.setAge(age);
                    break;
                }
                case 6: {
                    System.out.println("City : ");
                    String city = scanner.next();
                    passenger.setCity(city);
                    break;
                }
                case 7: {
                    init();
                    break;
                }
                default : {
                    System.out.println("Invalid option");
                }

            }
        }while(choice != 7);
        
        
    }

    @Override
    public void passengersNotFound() {
        System.out.println("Passenger you've chosen is not found.");
        System.out.println("Try again with correct passengers ID. ");
        updatePassenger();
    }

    public void totalFare(int total) {
        System.out.println("--------------------------------");
        System.out.println("Fare you've to pay for this journey : " + total + ".");
    }

    @Override
    public void displaysPassengers(List<Passengers> passengers) {
        for (int i = 0; i < passengers.size(); i++) {
            System.out.println("Passenger " + (i + 1) + " details : ");
            System.out.println("Name : \t" + passengers.get(i).getFirstName() + " " + passengers.get(i).getLastName());
            System.out.println("Contact : \t" + passengers.get(i).getContactNumber());
            System.out.println("Gender : \t" + passengers.get(i).getGender());
            System.out.println("Age : \t" + passengers.get(i).getAge());
            System.out.println("City : \t" + passengers.get(i).getCity());
            System.out.println("Passengers ID : " + passengers.get(i).getPassengersId());
            System.out.println("-------------------------------------------------------------");
        }
    }

    public void getTicket() {
        TicketViewCallBack tBack = new TicketView();
        tBack.init();
    }

}
