package com.MahadevanRDJ.FlightTicketBooking.Passengers;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Passengers;

public interface PassengersControllerCallBack {

    void storePassengers(String firstName, String lastName, long contactNumber, String gender, byte age, String city);

    void storeFare(byte numberOfPassengers);

    void totalFare(int total);

    void displayPassengers();

    void setNumberOfPassengers(byte numberOfPassengers);

    void displayPassengers(List<Passengers> passengersList);

    void getPassengers(int passengersId);

    void returnPassenger(Passengers passenger);

    void passengersNotFound();
    
}
