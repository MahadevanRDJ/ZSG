package com.MahadevanRDJ.FlightTicketBooking.Passengers;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Passengers;
import com.MahadevanRDJ.FlightTicketBooking.FlightRepository.FlightRepository;

public class PassengersModel implements PassengersModelCallBack {
    private PassengersModelControllerCallBack passengersController;

    public PassengersModel(PassengersModelControllerCallBack passengersController) {
        this.passengersController = passengersController;
    }

    @Override
    public void storePassengers(String firstName, String lastName, long contactNumber, String gender, byte age,
            String city) {
        FlightRepository.getInstance().storePassengers(firstName, lastName, contactNumber, gender, age, city);
    }

    @Override
    public void storeFare(byte numberOfPassengers) {
        FlightRepository.getInstance().setTicketFare(numberOfPassengers);
        totalFare(FlightRepository.getInstance().getTicketFare());

    }

    @Override
    public void totalFare(int total) {
        passengersController.totalFare(total);

    }

    @Override
    public void displayPassengers() {
        List<Passengers> passengersList = FlightRepository.getInstance().returnPassengers();
        passengersController.displayPassengers(passengersList);
    }

    @Override
    public void setNumberOfPassengers(byte numberOfPassengers) {
        FlightRepository.getInstance().setNumberOfPassengers(numberOfPassengers);
    }

    @Override
    public void getPassengers(int passengersId) {
        Passengers passenger = FlightRepository.getInstance().getPassengers(passengersId);
        if(passenger != null) {
            passengersController.returnPassenger(passenger);
        }
        else {
            passengersController.passengersNotFound();
        }
    }
}
interface PassengersModelControllerCallBack{

    void totalFare(int total);

    void displayPassengers(List<Passengers> passengersList);

    void getPassengers(int passengersId);

    void returnPassenger(Passengers passenger);

    void passengersNotFound();
}