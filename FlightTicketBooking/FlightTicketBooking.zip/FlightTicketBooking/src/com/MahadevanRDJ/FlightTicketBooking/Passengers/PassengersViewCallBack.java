package com.MahadevanRDJ.FlightTicketBooking.Passengers;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Passengers;

public interface PassengersViewCallBack {

    void displaysPassengers();

    void init();

    void totalFare(int total);

    void displaysPassengers(List<Passengers> passengersList);

    void upadteFields(Passengers passenger);

    void passengersNotFound();
}
