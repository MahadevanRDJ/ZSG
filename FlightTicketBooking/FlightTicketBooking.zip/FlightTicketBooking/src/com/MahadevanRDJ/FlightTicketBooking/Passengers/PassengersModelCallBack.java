package com.MahadevanRDJ.FlightTicketBooking.Passengers;

public interface PassengersModelCallBack {

    void storePassengers(String firstName, String lastName, long contactNumber, String gender, byte age, String city);

    void storeFare(byte numberOfPassengers);

	void displayPassengers();

    void setNumberOfPassengers(byte numberOfPassengers);

    void totalFare(int total);

    void getPassengers(int passengersId);

}
