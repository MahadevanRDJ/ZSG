package com.MahadevanRDJ.FlightTicketBooking.Passengers;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Passengers;

public class PassengersController implements PassengersControllerCallBack, PassengersModelControllerCallBack {
    private PassengersViewCallBack passengersView;
    private PassengersModelCallBack passengersModel;

    public PassengersController(PassengersViewCallBack passengersView) {
        this.passengersView = passengersView;
        this.passengersModel = new PassengersModel(this);
    }

    @Override
    public void storePassengers(String firstName, String lastName, long contactNumber, String gender, byte age,
            String city) {
        passengersModel.storePassengers(firstName, lastName, contactNumber, gender, age, city);
    }

    @Override
    public void storeFare(byte numberOfPassengers) {
        passengersModel.storeFare(numberOfPassengers);
    }

    @Override
    public void totalFare(int total) {
        passengersView.totalFare(total);
    }

    @Override
    public void displayPassengers() {
        passengersModel.displayPassengers();

    }

    @Override
    public void setNumberOfPassengers(byte numberOfPassengers) {
        passengersModel.setNumberOfPassengers(numberOfPassengers);

    }

    @Override
    public void displayPassengers(List<Passengers> passengersList) {
        passengersView.displaysPassengers(passengersList);

    }

    @Override
    public void getPassengers(int passengersId) {
        passengersModel.getPassengers(passengersId);
        
    }

    @Override
    public void returnPassenger(Passengers passenger) {
        passengersView.upadteFields(passenger);
        
    }

    @Override
    public void passengersNotFound() {
        passengersView.passengersNotFound();
        
    }

}
