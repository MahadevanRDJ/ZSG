package com.MahadevanRDJ.FlightTicketBooking.Payment;

public interface PaymentControllerCallBack {

    int getAmount();

    void getTicketId(int ticketId);
}
