package com.MahadevanRDJ.FlightTicketBooking.Payment;

public interface PaymentModelCallBack {

	int getAmount();
    
}
