package com.MahadevanRDJ.FlightTicketBooking.Payment;

class PaymentController implements PaymentControllerCallBack, PaymentModelControllerCallBack {
    private PaymentViewCallBack paymentView;
    private PaymentModelCallBack paymentModel;

    public PaymentController(PaymentViewCallBack paymentView) {
        this.paymentView = paymentView;
        this.paymentModel = new PaymentModel(this);
    }

    @Override
    public int getAmount() {
        return paymentModel.getAmount();

    }

    @Override
    public void getTicketId(int ticketId) {
        paymentView.ticketID(ticketId);

    }

}
