package com.MahadevanRDJ.FlightTicketBooking.Payment;

import com.MahadevanRDJ.FlightTicketBooking.FlightRepository.FlightRepository;

public class PaymentModel implements PaymentModelCallBack {
    private PaymentModelControllerCallBack paymentController;

    public PaymentModel(PaymentModelControllerCallBack paymentController) {
        this.paymentController = paymentController;
    }

    @Override
    public int getAmount() {
        int amount = FlightRepository.getInstance().getTicketFare();
        ticketID();
        return amount;
    }

    public void ticketID() {
        paymentController.getTicketId(FlightRepository.getInstance().getTicketId());
    }
}
interface PaymentModelControllerCallBack {

    void getTicketId(int ticketId);

}
