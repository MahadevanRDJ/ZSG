package com.MahadevanRDJ.FlightTicketBooking.Payment;

public interface PaymentViewCallBack {

    void init();

    void ticketID(int ticketId);
    
}
