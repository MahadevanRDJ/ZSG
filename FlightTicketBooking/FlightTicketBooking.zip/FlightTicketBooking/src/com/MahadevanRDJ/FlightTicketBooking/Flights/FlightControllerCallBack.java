package com.MahadevanRDJ.FlightTicketBooking.Flights;


public interface FlightControllerCallBack {

    void checkFlights(byte flightNumber);

    void displayFlights();

    void getFlights();
    
}
