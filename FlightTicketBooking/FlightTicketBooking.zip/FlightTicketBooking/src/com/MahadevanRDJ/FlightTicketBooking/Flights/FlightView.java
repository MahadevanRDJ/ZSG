package com.MahadevanRDJ.FlightTicketBooking.Flights;

import java.util.List;
import java.util.Scanner;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;
import com.MahadevanRDJ.FlightTicketBooking.Passengers.PassengersView;
import com.MahadevanRDJ.FlightTicketBooking.Passengers.PassengersViewCallBack;

public class FlightView implements FlightViewCallBack {
    private FlightControllerCallBack flightController;
    private Scanner scanner = new Scanner(System.in);

    public FlightView() {
        this.flightController = new FlightController(this);
    }

    private void displayFlights() {
        flightController.getFlights();
    }

    public void init() {
        int choice;
        do {
            System.out.println("--------------------------------");
            System.out.println("1.Display Flight List\n2.Let's travel\n3.EXIT...");
            System.out.println("Enter choice : ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    displayFlights();
                    break;
                case 2:
                    goFlight();
                    break;
                case 3:
                    System.out.println("Bye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        } while (choice != 3);
    }

    public void displayFlights(List<Flights> flights) {
        System.out.println("Number\tName\tDeparture\tArrival\t\tFares");
        for (int i = 0; i < flights.size(); i++) {
            flights.get(i).displays();
        }
    }

    private void goFlight() {
        System.out.println("--------------------------------");

        System.out.println("Flight Number :");
        byte flightNumber = scanner.nextByte();

        flightController.checkFlights(flightNumber);
    }

    @Override
    public void flightFound() {
        System.out.println("--------------------------------");
        System.out.println("The Flight, You've chosen is ready for the journey.");
        System.out.println("Let us know whom are ready for this journey.");
        PassengersViewCallBack pBack = new PassengersView();
        pBack.init();

    }

    @Override
    public void flightNotFound() {
        System.out.println("Dear Customer, fligth you've chosen is not scheduled.");
        System.out.println("Refer the flight list.");
        init();

    }
}
