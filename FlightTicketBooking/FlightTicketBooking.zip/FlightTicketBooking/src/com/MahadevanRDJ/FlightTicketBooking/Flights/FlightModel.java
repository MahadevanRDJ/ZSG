package com.MahadevanRDJ.FlightTicketBooking.Flights;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;
import com.MahadevanRDJ.FlightTicketBooking.FlightRepository.FlightRepository;

class FlightModel implements FlightModelCallBack {
    private FlightModelControllerCallBack flightController;

    public FlightModel(FlightModelControllerCallBack flightController) {
        this.flightController = flightController;
    }

    @Override
    public void checkFlights(byte flightNumber) {
        Flights flight = FlightRepository.getInstance().getFlight(flightNumber);
        if (flight != null) {
            flightController.flightFound();
        } else {
            flightController.flightNotFound();
        }
    }
    
    @Override
    public void displayFlights() {
        List<Flights> flights = FlightRepository.getInstance().returnFlightDB();
        flightController.displayFlightDB(flights);
    }
    
    
    interface FlightModelControllerCallBack {

        void flightNotFound();

        void flightFound();

        void displayFlightDB(List<Flights> flights);

    }
}
