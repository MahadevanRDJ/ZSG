package com.MahadevanRDJ.FlightTicketBooking.Flights;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;

public interface FlightViewCallBack {

    void init();

    void flightFound();

    void flightNotFound();

    void displayFlights(List<Flights> flights);
    
}
