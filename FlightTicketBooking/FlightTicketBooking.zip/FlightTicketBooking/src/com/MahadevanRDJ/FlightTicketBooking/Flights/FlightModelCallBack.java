package com.MahadevanRDJ.FlightTicketBooking.Flights;

public interface FlightModelCallBack {

    void checkFlights(byte flightNumber);

    void displayFlights();
    
}
