package com.MahadevanRDJ.FlightTicketBooking.Flights;

import java.util.List;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;
import com.MahadevanRDJ.FlightTicketBooking.Flights.FlightModel.FlightModelControllerCallBack;

public class FlightController implements FlightControllerCallBack, FlightModelControllerCallBack {
    private FlightViewCallBack flightView;
    private FlightModelCallBack flightModel;

    public FlightController(FlightViewCallBack flightView) {
        this.flightView = flightView;
        this.flightModel = new FlightModel(this);
    }

    @Override
    public void checkFlights(byte flightNumber) {
        flightModel.checkFlights(flightNumber);
    }

    @Override
    public void displayFlights() {
        flightModel.displayFlights();

    }

    @Override
    public void flightNotFound() {
        flightView.flightNotFound();

    }

    @Override
    public void flightFound() {
        flightView.flightFound();

    }

    @Override
    public void getFlights() {
        flightModel.displayFlights();

    }

    @Override
    public void displayFlightDB(List<Flights> flights) {
        flightView.displayFlights(flights);

    }

}
