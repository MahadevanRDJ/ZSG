package com.MahadevanRDJ.FlightTicketBooking.Ticket;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;

public interface TicketControllerCallBack {

    void getFlight();

    void showFlights(Flights flight);

    void bookTicket();

    void cancelTicket();
    
}
