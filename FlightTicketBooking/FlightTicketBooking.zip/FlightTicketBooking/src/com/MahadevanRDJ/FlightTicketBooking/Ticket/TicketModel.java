package com.MahadevanRDJ.FlightTicketBooking.Ticket;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;
import com.MahadevanRDJ.FlightTicketBooking.FlightRepository.FlightRepository;

public class TicketModel implements TicketModelCallBack {
    private TicketModelControllerCallBack ticketController;

    public TicketModel(TicketModelControllerCallBack ticketController) {
        this.ticketController = ticketController;
    }

    @Override
    public void getFlight() {
        Flights flight = FlightRepository.getInstance().returnFlight();
        ticketController.showFlights(flight);
    }

    @Override
    public void bookTicket() {
        FlightRepository.getInstance().generateTicket();
    }

    @Override
    public void cancelTicket() {
        FlightRepository.getInstance().deleteTicket();
    }

}

interface TicketModelControllerCallBack{

    void showFlights(Flights flight);

}