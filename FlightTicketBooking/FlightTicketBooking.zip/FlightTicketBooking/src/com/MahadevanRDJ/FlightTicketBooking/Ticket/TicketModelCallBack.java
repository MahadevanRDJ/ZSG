package com.MahadevanRDJ.FlightTicketBooking.Ticket;

public interface TicketModelCallBack {

    void getFlight();

    void bookTicket();

    void cancelTicket();
    
}
