package com.MahadevanRDJ.FlightTicketBooking.Ticket;

import java.util.Scanner;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;
import com.MahadevanRDJ.FlightTicketBooking.Payment.PaymentView;
import com.MahadevanRDJ.FlightTicketBooking.Payment.PaymentViewCallBack;

public class TicketView implements TicketViewCallBack {
    private TicketControllerCallBack ticketController;
    private Scanner scanner = new Scanner(System.in);
    private boolean tiketBooked = false;

    public TicketView() {
        this.ticketController = new TicketController(this);
    }

    public void init() {
        int choice;
        do {
            System.out.println("-------------------------------------------");
            System.out.println(
                    "1. Get flight information\n2. Book ticket\n3. Cancel ticket\n4. Pay\n5. Invalid choice\n6. EXIT");
            System.out.println("Choice : ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    getFlightInfo();
                    break;
                case 2:
                    bookTicket();
                    break;
                case 3:
                    if (tiketBooked){
                        System.out.println("Are you sure to cancel the ticket? [YES/NO] ");
                        if (scanner.next().equalsIgnoreCase("no")) init();
                        else {
                            cancelTicket();
                            System.exit(0);
                        }
                    }
                    else init();
                    break;
                case 4:
                    if (tiketBooked)
                        pay();
                    break;
                case 5:
                    System.out.println("Invalid choice");
                    break;
                case 6:
                    System.exit(0);
                    break;
            }
        } while (choice != 5);

    }

    private void getFlightInfo() {
        ticketController.getFlight();
    }

    private void bookTicket() {
        ticketController.bookTicket();
        tiketBooked = true;
        System.out.println("Ticket Booked successfully.");
    }

    public void cancelTicket() {
        ticketController.cancelTicket();
    }

    private void pay() {
        PaymentViewCallBack pBack = new PaymentView();
        pBack.init();
    }

    @Override
    public void showFlights(Flights flight) {
        System.out.println("--------------------------------");
        System.out.println("Lets GO! ");
        System.out.println("Flight Number : " + flight.getFlightNumber());
        System.out.println("Flight Name : " + flight.getFlightName());
        System.out.println("Flight departure place : " + flight.getDeparturePlace());
        System.out.println("Flight arrival time : " + flight.getArrivalPlace());
        System.out.println("Fligth fare : " + flight.getFlightFares());
    }

}
