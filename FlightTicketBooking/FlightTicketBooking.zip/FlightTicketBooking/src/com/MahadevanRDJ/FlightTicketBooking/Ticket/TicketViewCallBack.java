package com.MahadevanRDJ.FlightTicketBooking.Ticket;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;

public interface TicketViewCallBack {

    void init();

    void showFlights(Flights flight);
    
}
