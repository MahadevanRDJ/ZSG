package com.MahadevanRDJ.FlightTicketBooking.Ticket;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;

public class TicketController implements TicketControllerCallBack, TicketModelControllerCallBack {
    private TicketViewCallBack ticketView;
    private TicketModelCallBack ticketModel;

    public TicketController(TicketViewCallBack ticketView) {
        this.ticketView = ticketView;
        this.ticketModel = new TicketModel(this);
    }

    @Override
    public void getFlight() {
        ticketModel.getFlight();

    }

    @Override
    public void showFlights(Flights flight) {
        ticketView.showFlights(flight);

    }

    @Override
    public void bookTicket() {
        ticketModel.bookTicket();

    }

    @Override
    public void cancelTicket() {
        ticketModel.cancelTicket();

    }

}
