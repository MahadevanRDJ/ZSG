package com.MahadevanRDJ.FlightTicketBooking.FlightRepository;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.MahadevanRDJ.FlightTicketBooking.DTOs.Admin;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Flights;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Passengers;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Ticket;
import com.MahadevanRDJ.FlightTicketBooking.DTOs.Users;

public class FlightRepository {
    private static FlightRepository flightInstance;
    
    private List<Users> users = new ArrayList<Users>();
    private List<Passengers> passengers = new ArrayList<Passengers>();
    private List<Flights> flights = new ArrayList<Flights>();
    private List<Admin> admin = new ArrayList<Admin>();
    private Flights flight;
    private Ticket ticket;
    private boolean flightStored = false;
 
    private FlightRepository() {

    }

    public static FlightRepository getInstance() {
        if (flightInstance == null) {
            flightInstance = new FlightRepository();
        }
        return flightInstance;
    }

    private void adminUsers() {
        admin.add(new Admin("Zoho", "Zoho"));
        admin.add(new Admin("Deva", "Zsgs")); 
    }

    public Admin getAdmin(String username, String password) {
        adminUsers();
        for (Admin a : admin) {
            if (a.getAdminName().equals(username) && a.getPassword().equals(password)) {
                return a;
            }
        }   
        return null;
    }
    
    public void addUser(String username, String password) {
        users.add(new Users(username, password));
    }
    
    public Users getUser(String username, String password) {
        for (Users u : users) {
            if (u.getUserName().equals(username) && u.getUserPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    private void storeFlights() {
        try {
            Scanner input = new Scanner(new File("E:\\FlightTicketBooking\\src\\com\\MahadevanRDJ\\FlightTicketBooking\\flightsdatabse.txt"));
            while (input.hasNextLine()) {
                flights.add(new Flights(input.nextByte(), input.next(), input.next(), input.next(), input.nextInt()));
            }
            input.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Flights getFlight(byte flightNumber) {
        if(flightStored == false) storeFlights();
        for (Flights f : flights) {
            if (f.getFlightNumber() == flightNumber) {
                flight = f;
                initialTicket();
                return f;
            }
        }
        flightStored = true;
        return null;
    }


    public Flights returnFlight() {
        return flight;
    }

    public void generateTicket() {
        ticket.setFlightName(flight.getFlightName());
        ticket.setFlightNumber(flight.getFlightNumber());
        ticket.setArrivalPlace(flight.getArrivalPlace());
        ticket.setDeparturePlace(flight.getDeparturePlace());
        ticket.setTicketFare(ticket.getTicketFare());
        ticket.setTicketId(new Random().nextInt(1000));
        ticket.setNumberOfPassengers(ticket.getNumberOfPassengers());
    }

    public void initialTicket() {
        ticket = new Ticket((byte)0, flight.getFlightName(), flight.getDeparturePlace(), flight.getArrivalPlace(), (byte) 0 , 0 , 0);
    }

    public void setNumberOfPassengers(byte numberOfPassengers) {
        ticket.setNumberOfPassengers(numberOfPassengers);
    }


    public void setTicketFare(byte numberOfPassengers) {
        ticket.setTicketFare(ticket.getNumberOfPassengers() * flight.getFlightFares());
    }

    public int getTicketFare() {
        return ticket.getTicketFare();
    }

    public Ticket returnTicket() {
        return ticket;
    }

    public int getTicketId() {
        return ticket.getTicketId();
    }
    public void deleteTicket() {
        passengers = null;
        flight = null;
        ticket = null;
    }

    public void storePassengers(String firstName, String lastName, long contactNumber, String gender, byte age, String city) {
        passengers.add(new Passengers(firstName, lastName, contactNumber, gender, age, city, new Random().nextInt(2000, 3000)));
    }  

    public Passengers getPassengers(int passengersId) {
        for(Passengers passenger : passengers) {
            if(passengersId == passenger.getPassengersId()) {
                return passenger;
            }
        }
        return null;
    }

    public List<Passengers> returnPassengers() {
        return passengers;
    }
    
    public List<Flights> returnFlightDB() {
        if(flightStored == false) storeFlights();
        return flights;
    }


}
